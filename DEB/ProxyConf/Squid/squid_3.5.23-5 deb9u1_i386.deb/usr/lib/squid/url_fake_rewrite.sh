#!/bin/sh
#
## Copyright (C) 1996-2016 The Squid Software Foundation and contributors
##
## Squid software is distributed under GPLv2+ license and includes
## contributions from numerous individuals and organizations.
## Please see the COPYING and CONTRIBUTORS files for details.
##
#
# Copyright (c) 2009-2014, Treehouse Networks Ltd. New Zealand
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
#
# 1. Redistributions of source code must retain the above copyright
# notice, this list of conditions and the following disclaimer.
#
# 2. Redistributions in binary form must reproduce the above copyright
# notice, this list of conditions and the following disclaimer in the
# documentation and/or other materials provided with the distribution.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
# COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.
#

if test "${1}" = "-h" ; then
	echo "Usage: $0 [-h] [-c] [-d logfile]"
	echo "  -h           Help: this help text"
	echo "  -c           Accept concurrent request format"
	echo "  -d logfile   Debug: log all data received to the named file"
	exit 1
fi

concurrent=0
if test "${1}" = "-c" ; then
	concurrent=1
	shift
fi

DEBUG=0
if test "${1}" = "-d" ; then
	DEBUG=1
	LOG="${2}"
fi

if test "$concurrent" = "1"; then
	# read concurrent input format
	while read id url rest; do
		if test "${DEBUG}" = "1" ; then
			echo "ID:$id URL:$url EXTRAS:$rest" >>${LOG}
		fi
		# blank URL for no change, or replace with another URL.
		echo "${id} "
	done
else
	# read old non-concurrent input format
	while read url rest; do
		if test "${DEBUG}" = "1" ; then
			echo "URL:$url EXTRAS:$rest" >>${LOG}
		fi
		# blank line/URL for no change, or replace with another URL.
		echo
	done
fi
